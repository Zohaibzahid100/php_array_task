<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
<section class='container one' hight='800px' width='100%' >
    <div class='row justify-content-center'>
        <div class='col-6'>
            <h2>Fill this form</h2>
            <form  method='POST' enctype="multipart/form-data">
                <input type='text'name='username'class='form-control mb-2' placeholder='Enter your name'>
                <input type='text'name='Email'class='form-control mb-2' placeholder='Enter your Email'>
                <input type='text'name='Phone'class='form-control mb-2' placeholder='Enter your Phone'>
                <textarea name='massage' class='form-control mb-2' placeholder='Enter your Phone'></textarea>
            <input type="file" name="file">
                <button type='submit' name='btn_submit' class='btn btn-primary w-100'>Submit</button>
            </form>
        </div>
    </div>
</section>
   
</body>
</html>
<?php
if(isset($_POST['btn_submit'])){
    $username = $_POST['username'];
    $email = $_POST['Email'];
    $phone = $_POST['Phone'];
    $massage = $_POST['massage'];
   echo  $username."<BR>".$email.$phone.$massage."<BR>" ;

   $image = $_FILES['file']["name"];
   $tmp_name = $_FILES["file"]["tmp_name"];
   $img_size= $_FILES["file"]["size"];
   $maxsize = 500000;
   echo "image size :".$maxsize;
   echo "<br>";
   $location = "img/";
   if($img_size < $maxsize){
     if( move_uploaded_file($tmp_name, $location. $image)){
        echo "Image uploaded successfully";
     }
     else{
        echo "Failed to upload image";
     }
   
   }
   else{
    echo"size file : 100000 uploade felled";
}
if($img_size < $maxsize){
    echo "<section> <img src='img/".$image."'></section>";
}


}

?>