<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
     //index arrays 
    echo "<H1> INDEX ARRAYS </H1>";


    $arr1 = array("apple", "banana", "cherry");
    $arr2 = array("date", "elderberry", "fig");
    $arr3 = array("grape", "honeydew", "kiwi");
 echo $arr2[0]."<br>".$arr2[1]."<br>".$arr2[2];
 echo $arr3[0]."<br>".$arr3[1]."<br>".$arr3[2];

    foreach($arr1 as $Z){
        echo $Z."<br>";
        
    }

// Associative arrays

echo "<H1> ASSOCIATIVE ARRAYS </H1>";

    $arr4 = array ("frui3" => "apple", "vegetable" => "banana", "fruit" => "cherry");
    foreach ($arr4 as $i => $a){
      echo $i. "=" .$a. "<br>";
        
    }

 $cars1 = [];
 $cars1[0] = "farrari";
 $cars1[1] = "BMW";
 $cars1[2] = "Tesla";
 echo $cars1[0];
 echo '<br>';
 echo $cars1[1];
 echo '<br>';
 echo $cars1[2];

 echo '<br>';

    ?>

    <?php
    
    $susses_array = [
        'Ali' => array('Math' =>10,'english' => 30,'urdu' => 50),
        'Ahmad' => array('Math' => 40,'english' => 60,'urdu' => 70),
        'Osman' => array('Math' => 80,'english' => 90,'urdu' => 100),
    ];

    foreach( $susses_array as $key){
        echo "Name :".$key."<br>";
        foreach($key as $subkey => $subvalue){
            echo $subkey." : ".$subvalue."<br>";
        }
        echo "<br>";
    }
    
    ?>
</body>
</html>