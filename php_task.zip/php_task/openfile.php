<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<style>
    .abc{
        height:130px;
    }
</style>
<body>
    <section class='container one' hight='800px' width='100%' >
        <div class='row justify-content-center'>
            <div class='col-6'>
                <h2>Fill this form</h2>
                <form  method='POST' enctype="multipart/form-data">
                    <input type='text' name=' ' class='form-control mb-2' placeholder='Enter your name'>
                    <input type='email' name='email' class='form-control mb-2' placeholder='Enter your Email'>
                    <input type='text' name='massagebox' class='form-control mb-2 abc' placeholder='Enter your massage'>
                    <button name='btn-sub' class='btn btn-primary'> submit</button>
                </form>
            </div>
        </div>
    </section>
</body>
</html>
<?php
if(isset($_POST['btn-sub'])){
    $username = $_POST['username'];
    $email = $_POST['email'];
    $massage = $_POST['massagebox'];

}

$file = fopen("data.txt", 'w');
fwrite($file,"Name :".$username."Email: ".$email."Massage: ".$massage );



?>