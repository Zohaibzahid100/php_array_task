<?php
$hostingName = "localhost";
$UserName = "root";
$passward = "";
$DatabaseName = "crud";

$con = mysqli_connect($hostingName,$UserName,$passward,$DatabaseName);

// if($con){
//     echo "database connect sucessfully";
// }
// else{
//     echo "database connection failed";
// }

?>