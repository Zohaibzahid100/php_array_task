<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<style>
    *{
        padding: 0%;
        margin:0%;

    }
    .hello{
        background-color:lightgray;
        height: 100vh;
    }
    .hello1{
        border:1px solid black;
        
        
    }
    td,th{
        text-align:center;
 font-size:20px;
 
    }
</style>
<?php
include("db.php");
?>
<body>
<div class="container-fluid hello">
    <div class="row ">
        <div class="col-12 ">
          <table class="table hello1 ">
            <thead>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>User_img</th>
                <th>Action</th>
            </thead>
            <tbody>
                <?php
                $query = "SELECT* from users";
                $result = mysqli_query($con, $query);
            
                while($row = mysqli_fetch_assoc($result)){
                echo "<tr>";
                echo "<td>".$row['Name']."</td>";
                echo "<td>".$row['Email']."</td>";
                echo "<td>".$row['Phone']."</td>";
                echo "<td>".$row['Address']."</td>";
                echo "<td><img src='" . $row['User_img'] . "' width='80px' height='80px'></td>";

       echo "<td><a class='btn btn-primary'>Edit</a> <a class='btn btn-danger' href='delete.php?id=".$row["id"]."' >Delete</a></td>";
      echo "</tr>";

                }
                ?>
                


            </tbody>
          </table>
        </div>
    </div>
</div>
    
</body>
</html>