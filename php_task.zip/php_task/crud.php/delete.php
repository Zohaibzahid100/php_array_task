<?php

include("db.php");

$id = $_GET["id"];
echo $id;
$delete = "DELETE from users where id = $id ";
$deleteRun = mysqli_query($con,$delete);
if($deleteRun){
    header("Location:read.php");
}




?>