<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <section class="container">
        <div class=" row justify-content-center d-flex align-items-flex-end">
            <div class="col-8">
                <form method="post" enctype="multipart/form-data">
                    <h1>FILL YOUR FORM</h1>
                    <input type="text" name="username" class="form-control mb-2" placeholder="Enter Your Name" required>
                    <input type="email" name="email" class="form-control mb-2" placeholder="Enter Your email" required>
                    <input type="phone" name="phone" class="form-control mb-2" placeholder="Enter Your Phone Number"required>
                    <input type="text" name="address" class="form-control mb-2" placeholder="Enter Your Adress" required>
                    <input type="file" name="file" class="form-control mb-2" required>
                    <button class="btn btn-danger w100" name="submit-btn">Submit Form</button>
                </form>
            </div>
        </div>
    </section>
</body>
</html>
<?php
include ("db.php");

   if(isset($_POST['submit-btn'])) {
       $username = $_POST['username'];
       $email = $_POST['email'];
       $phone = $_POST['phone'];
       $address = $_POST['address'];
       $image = $_FILES["file"]["name"];
       $tmp_name = $_FILES["file"]["tmp_name"];
       $folder_name = "images/";
   
       if( move_uploaded_file($tmp_name, $folder_name. $image)){
        $imag_path = $folder_name. $image;

        $sql = "INSERT INTO users (Name, Email, Phone, Address,User_img) VALUES ('$username', '$email', '$phone', '$address','$imag_path')";
        $queryRun = mysqli_query($con,$sql);
        if($queryRun ) {
           header('location:read.php');
            // echo "<script>alert('form submit sucessfully')</script>";
        } else{
            echo "<script>alert('Error inserting data into database')</script>";
        }
     }else{
        echo "<script>alert('Error uploading the image')</script>";
     }
   }
   
  

  

  



?>