<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<style>
      *{
        padding: 0%;
        margin: 0%;
        box-sizing:border-box;
    }
    .sec-sign-in{
        width: 100%;
        height:100vh;
        display: flex;
        justify-content: center;
        background-image:url(images/123.avif);
     background-position:center;
        background-size:cover;
        align-items:center;
        background-color:lightgray;
        
    }
    .form-paremt{
        background-color:white;
        padding: 30px;
    }
    .hadding-sign-in{
        text-align:center;
    }
    
</style>
<body>
<div class="sec-sign-in ">
    <div class="col-md-4 form-paremt">
        <h2 class="mb-4 hadding-sign-in">Sign In Form</h2>
        <form method="POST" >
        <div class="mb-3">
                <label  class="form-label">Username:</label>
                <input type="text" class="form-control" name="username" required>
            </div>
            <div class="mb-3">
                <label  class="form-label">Email:</label>
                <input type="email" class="form-control" name="email" required>
            </div>
            <div class="mb-3">
                <label  class="form-label">Password:</label>
                <input type="password" class="form-control" name="password" required>
            </div>
            <button type="submit" name="login" class="btn btn-primary w-100 mt-3">Sign In
          
            </button>
        </form>
        </div>
    </div>
    <?php
include("config.php");
session_start();
if(isset($_SESSION['user_name'])){
    header('location:dashboard.php');
}else{
 if(isset($_POST["login"])){
    $user_name = $_POST['username'];
   $user_email = $_POST['email'];
   $user_passwoed = md5($_POST['password']);

   $result = mysqli_query($conn, "SELECT * FROM `registration` WHERE  Email='$user_email' And Password='$user_passwoed'");
   if(mysqli_num_rows($result)){
    $_SESSION['user_name']=$user_name;
    header("location:dashboard.php");
   }else{
    echo
    "<script>
    alert('email is aldredy teken')
    </script>";
    header("location:sign-in.php");
   }

 }
}


?>  
</body>
</html>
