<?php
include('config.php');
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<style>
    *{
        padding: 0%;
        margin: 0%;
        box-sizing:border-box;
        color:white
    }
    .navigation{
      position: relative;
      padding-left: 22%;
    }
    .sec-123{
    position:absolute;
    top:0%;

    left:0%;
    height: 100vh;
    width: 23%;
    background-color: rgb(10, 1, 18);
   
  }
  .hamburger{
    display:;
    cursor:pointer;
    margin:5px 10px;
  }
  .hamburger div{
     width:30px;
  height:5px;
  margin:5px 0px;
  background-color: rgb(10, 1, 18);
    }
    .logo-and-text{
      padding-top: 8%;
      padding-left: 20px;
      padding-bottom: 20px;
      
       display: flex;
       border-bottom:1px solid white;
    }
    .haddin-logo{
      font-size:30px;
      color:white;
      padding-top:7% ;
      padding-left:4% ;
      font-family: serif;
      font-weight: bolder;
    }
    .home{
      margin-top: 8%;
    
      padding-left: 10px;
      display:flex;
      
    }
    .home1{
      font-size:20px;
      padding-left:10px;
      padding-top:2%;
      color:lightgray;
    }
    .home-ha{
      padding-left: 10px;
      padding-top: 2.5%;
      font-size:15px;
      font-weight: 400;
    }
    .hi{
      background-color: blue;
      height: 40px;
      padding: 5px;
      border:0.5px solid white;

    }
    .hello{
      height: 543px;
      background-color:blue;
      margin-left:23%;
    }


</style>
<body>
<nav class="navbar navbar-light bg-light  navigation">
  <div class="container-fluid" style=" justify-content:space-between;">
  <div class="hamburger">
  <div></div>
  <div></div>
  <div></div>
</div>
    <div class="navbar-brand">
      <img src="images/aaa.avif" alt="" width="40" height="35" class="d-inline-block align-text-top " style="border-radius:50%;" >
      Hi, <?php
        echo $_SESSION['user_name']; 
      ?>
      <a href="logout.php" class="btn btn-primary"> Log Out</a> 
    </div>
  </div>
</nav>
<div class="sild-bar sec-123">
  <div class="logo-and-text">
    <img src="images/asas-removebg-preview.png" alt="" class="image-fluid " width="25%" height="25%">
    <h2 class="haddin-logo">E- commerce </h2>
  </div>
  <div class="home hi">
  <i class="fa-solid fa-house-chimney  home1"></i>
    <H5 class="home-ha"> Home</H5>
  </div>
  <div class="home">
  <i class="fa-solid fa-gauge-high  home1 "></i>
    <H5 class="home-ha"> Dashboard</H5>
  </div>
  <div class="home">
  <i class="fa-brands fa-first-order  home1"></i>
    <H5 class="home-ha"> Order</H5>
  </div>
  <div class="home">
  <i class="fa-brands fa-product-hunt  home1"></i>
    <H5 class="home-ha"> Product</H5>
  </div>
  <div class="home">
  <i class="fa-solid fa-user  home1"></i>
    <H5 class="home-ha"> Profile</H5>
  </div>
</div>

<section class="hello">
  <img src="images/dashboardimages.webp" alt="" class="image-fluid" width="100%" height="100%">
  
</section>
    
</body>
</html>