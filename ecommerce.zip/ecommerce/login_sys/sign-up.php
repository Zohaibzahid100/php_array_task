<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sign up</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<style>
    *{
        padding: 0%;
        margin: 0%;
        box-sizing:border-box;
    }
    .sec-sing-up{
        width: 100%;
        height:100vh;
        display: flex;
        justify-content: center;
        background-image:url(images/123.avif);
     background-position:center;
        background-size:cover;
        align-items:center;
        background-color:lightgray;
    }
    .form-paremt{
        
        background-color:white;
         padding: 20px;

    }
    .form-input{
        width: 100%;
        height: 37px;
        border:1px solid lightgray;
        padding-left: 10px;
       margin-bottom:10px;
    }
    .fn-ln-input{
        width: 40%;
    }
    .fnln-put{
        display: flex;
    }
    .ss{
        margin-left:38%;
    }
    .ii{
        margin-left:10%;
    }

</style>
<body>
<section class="sec-sing-up">
    <div class="col-md-6 form-paremt ">
    <h2 style="text-align:center;" mb-1>Sign Up Form</h2>
    <form method="POST" enctype="multipart/form-data" >
    <label >Fastname:</label>
    <label class="ss" >Fastname:</label>
        <div class="fnln-put">
        <input type="text" name="Fastname" class="form-input fn-ln-input " placeholder="Enter Your Fastname" required><br>
        <input type="text" name="Lastname" class="form-input fn-ln-input ii" placeholder="Enter Your Lastname" required><br>
        </div>
        <label>Email:</label>
        <input type="email" name="email" class="form-input " placeholder="Enter Your Email" required><br>
        <label >Date of the day:</label>
        <input type="date" name="Birthday" class="form-input " placeholder="Enter Your Date Of The Day" required><br>
        <label >Password:</label>
        <input type="password" name="password" class="form-input " placeholder="Enter Your Password" required><br>
        <label >Confirm Password:</label>
        <input type="password" name="confirm_password" class="form-input " placeholder="Enter Your Confirm Password " required><br>
        <input type="submit" name="register" value="Sign Up" class="btn btn-primary w-100 mt-4">
    </form>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
include("config.php");

if (isset($_POST['register'])) {
    $firstname = $_POST['Fastname'];
    $lastname = $_POST['Lastname'];
    $email = $_POST['email'];
    $birthday = $_POST['Birthday'];
    $password = md5($_POST['password']);
    $confirm_password =md5( $_POST['confirm_password']);
    
    $dup_Email = mysqli_query($conn, "SELECT * FROM `registration` WHERE Email='$email'");
  if(mysqli_num_rows($dup_Email)){
    echo
    "<script>
    alert('email is aldredy teken')
    </script>";
  }else{
    if ($password===$confirm_password){

        $query = "INSERT INTO registration (Fastname, lastname, Email, Date_of_birth, password) 
                  VALUES ('$firstname', '$lastname', '$email', '$birthday', '$password')";
             $qureyrun = mysqli_query($conn,$query);        
        if ($qureyrun) {
            header("location:sign-in.php");
        } else {
         echo "samething want wrong";
        }
    } else {
       
        echo "<script> alert('password cant not metch')</script>";
    }
}
}
?>













