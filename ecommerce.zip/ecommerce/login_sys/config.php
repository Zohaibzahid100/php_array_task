<?php
$servername = "localhost";
$username = "root";
$password = "";
$databasename = "login-system";

$conn = mysqli_connect("$servername","$username","$password","$databasename");
// if($conn){
//     echo"database sucessfully";
// }else{
//     echo"database can not sucessfully";
// }


?>